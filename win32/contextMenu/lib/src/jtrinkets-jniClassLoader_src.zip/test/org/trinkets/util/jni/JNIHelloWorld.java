package org.trinkets.util.jni;

/**
 * JNI interface
 *
 * @author Alexey Efimov
 */
public interface JNIHelloWorld {
    public void sayHello(String hello);
}
